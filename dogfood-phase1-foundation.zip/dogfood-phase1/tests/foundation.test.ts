import { describe, expect, it } from "vitest";

describe("foundation", () => {
  it("has a working test runner", () => {
    expect(1 + 1).toBe(2);
  });

  it("keeps the app contract intentionally minimal", () => {
    expect(process.env.NODE_ENV ?? "test").toBeTypeOf("string");
  });
});
