/**
 * Phase 1 importer boundary.
 * The concrete fixture schema is intentionally not guessed here.
 * Phase 2 will validate the official fixtures.json and map it to domain entities.
 */
export type FixtureImportPlan = Readonly<{
  users: number;
  events: number;
  tracks: number;
  teams: number;
  projects: number;
  judges: number;
  assignments: number;
  scores: number;
}>;

export function planImport(_raw: unknown): never {
  throw new Error("Official fixture importer is a Phase 2 task");
}
