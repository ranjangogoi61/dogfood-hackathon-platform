import { NextResponse } from "next/server";
import { pingDatabase } from "@/lib/db";

export const dynamic = "force-dynamic";

export async function GET() {
  const dbOk = await pingDatabase();

  if (!dbOk) {
    return NextResponse.json({ ok: false, db: "down" }, { status: 503 });
  }

  return NextResponse.json({ ok: true, db: "up" });
}
