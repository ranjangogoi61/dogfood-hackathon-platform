export default function HomePage() {
  return (
    <main style={{ padding: "2rem", maxWidth: 720, margin: "0 auto" }}>
      <h1>Dogfood</h1>
      <p>Offline-first, self-hostable hackathon platform.</p>
      <p>Foundation phase. Business features land in later phases.</p>
      <ul>
        <li><a href="/api/health">/api/health</a> — liveness</li>
        <li><a href="/api/ready">/api/ready</a> — database readiness</li>
      </ul>
    </main>
  );
}
