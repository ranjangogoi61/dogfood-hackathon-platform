export { db, pingDatabase } from "./client";
