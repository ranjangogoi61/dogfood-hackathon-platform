# Dogfood — Phase 1 Foundation

This folder contains the Phase 1 foundation only.

## Status

- Next.js App Router skeleton
- PostgreSQL container
- Drizzle schema/configuration
- Foundation database bootstrap
- Docker Compose startup path
- `/api/health`
- `/api/ready`
- Vitest foundation
- Official `.dogfood.toml` shape with no claimed tiers

## Important

`fixtures.json` importing and business tables belong to Phase 2. Do not treat the
foundation metadata table as the final domain schema.

The official Dogfood acceptance runner remains the source of `acceptance-report.txt`.
This phase does not fabricate an acceptance result.
